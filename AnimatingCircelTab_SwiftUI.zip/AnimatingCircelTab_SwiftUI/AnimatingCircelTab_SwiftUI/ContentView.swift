//
//  ContentView.swift
//  AnimatingCircelTab_SwiftUI
//
//  Created by Anthony Design Code on 28/04/2020.
//  Copyright © 2020 AnthonyDesignCode.io. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State var selected = 0
    
    var body: some View {
        VStack {
            ZStack {
                if self.selected == 0 {
                    Color.black
                } else if self.selected == 1 {
                    Color.green
                } else if self.selected == 2 {
                    Color.red
                } else if self.selected == 3 {
                    Color.blue
                }
            }
            CircleTab(selected: self.$selected)
        }
        .edgesIgnoringSafeArea(.top)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct CircleTab : View {
    
    @Binding var selected: Int
    
    var body: some View {
        HStack {
            Button(action: {
                self.selected = 0
            }){
                VStack {
                    if self.selected != 0 {
                        Image(systemName: "house.fill")
                            .foregroundColor(Color.black.opacity(0.2))
                    } else {
                        Image(systemName: "house.fill")
                            .resizable()
                            .frame(width: 25, height: 25)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.yellow)
                            .clipShape(Circle())
                            .offset(y: -20)
                            .padding(.bottom, -20)
                        Text("Home")
                            .foregroundColor(Color.black.opacity(0.7))
                    }
                }
            }
            Spacer(minLength: 15)
            
            Button(action: {
                self.selected = 1
            }){
                VStack {
                    if self.selected != 1 {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(Color.black.opacity(0.2))
                    } else {
                        Image(systemName: "magnifyingglass")
                            .resizable()
                            .frame(width: 25, height: 25)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.orange)
                            .clipShape(Circle())
                            .offset(y: -20)
                            .padding(.bottom, -20)
                        Text("Search")
                            .foregroundColor(Color.black.opacity(0.7))
                    }
                }
            }
            Spacer(minLength: 15)
            
            Button(action: {
                self.selected = 2
            }){
                VStack {
                    if self.selected != 2 {
                        Image(systemName: "heart.fill")
                            .foregroundColor(Color.black.opacity(0.2))
                    } else {
                        Image(systemName: "heart.fill")
                            .resizable()
                            .frame(width: 25, height: 25)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.yellow)
                            .clipShape(Circle())
                            .offset(y: -20)
                            .padding(.bottom, -20)
                        Text("Likes")
                            .foregroundColor(Color.black.opacity(0.7))
                    }
                }
            }
            Spacer(minLength: 15)
            
            Button(action: {
                self.selected = 3
            }){
                VStack {
                    if self.selected != 3 {
                        Image(systemName: "person.fill")
                            .foregroundColor(Color.black.opacity(0.2))
                    } else {
                        Image(systemName: "person.fill")
                            .resizable()
                            .frame(width: 25, height: 25)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.orange)
                            .clipShape(Circle())
                            .offset(y: -20)
                            .padding(.bottom, -20)
                        Text("Profile")
                            .foregroundColor(Color.black.opacity(0.7))
                    }
                }
            }
        }
        .padding(.vertical, -10)
        .padding(.horizontal, 25)
        .background(Color.white)
        .animation(.spring())
    }
}
